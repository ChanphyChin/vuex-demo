export default {
    state:{
        user_name:"userName from Vuex"
    },
    mutations:{
    	//this.$store.commit("showUserName") 组件中以这样的形式可以调用到mutations里面的方法
    	//这里的参数state就是组件中调用的$store
        changeUserName(state){
        	// alert(state.user_name+'123')
        }
    }
}