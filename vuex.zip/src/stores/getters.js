//getters能够取得state里面的属性值，即使在getters里更改，也无法更改state里面的对应属性值
//类似于组件中的computed
export const test = state =>{
	return !state.show;
}