import	Vue from 'vue'
import Vuex from 'vuex'
import * as getters from './getters'
import modules1 from './modules1'

Vue.use(Vuex);
export default new Vuex.Store({
    state:{
        name:"userName from state",
        show:true
    },
    modules: {
    	//这里可以放置多个state模块，组件内部调用方法为this.$store.state+模块名称+需要操作的变量
        modules1: modules1
    },
    mutations:{
    	//this.$store.commit("showUserName") 组件中以这样的形式可以调用到mutations里面的方法
    	//这里的参数state就是组件中调用的$store
        changeUserName(state){
        	//修改模块中的属性
            state.modules1.user_name = 'change satate modules1 name';
            //修改当前state中的属性
            state.name = 'change state name';
        },
        showNames(state){
        	alert(state.modules1.user_name);
        	alert(state.name);
        }
    },
    actions:{
        getMutationsFn(context){
        //这里的context和我们使用的$store拥有相同的对象和方法
        //组件中使用this.$store.dispatch('getMutationsFn')来触发actions里面的方法
        //context.commit(argument)中的参数为字符串且为mutations中的方法名
            context.commit('changeUserName');
            //你还可以在这里触发其他的mutations方法
            //context.commit('showNames');
        },
    },
    getters
})