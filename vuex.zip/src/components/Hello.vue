<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <h2>Essential Links</h2>
    <ul>
      <li><a href="https://vuejs.org" target="_blank">Core Docs</a></li>
      <li><a href="https://forum.vuejs.org" target="_blank">Forum</a></li>
      <li><a href="https://gitter.im/vuejs/vue" target="_blank">Gitter Chat</a></li>
      <li><a href="https://twitter.com/vuejs" target="_blank">Twitter</a></li>
      <br>
      <li><a href="http://vuejs-templates.github.io/webpack/" target="_blank">Docs for This Template</a></li>
    </ul>
    <h2>Ecosystem</h2>
    <ul>
      <li><a href="http://router.vuejs.org/" target="_blank">vue-router</a></li>
      <li><a href="http://vuex.vuejs.org/" target="_blank">vuex</a></li>
      <li><a href="http://vue-loader.vuejs.org/" target="_blank">vue-loader</a></li>
      <li><a href="https://github.com/vuejs/awesome-vue" target="_blank">awesome-vue</a></li>
    </ul>
  </div>
</template>

<script>
//引入css样式表
import '../styles/hello.css';
//引入mapState插件，可以重定向实例中调用vuex中的方法的别名
import { mapState } from 'vuex';

//export default 里面的内容是组件中暴露给vue进行处理的内容
//其中data为组件中定义需要用到的数据的地方
//methods为组件中定义方法的地方
//computed为组件检查数据变动的钩子
//beforeRouteEnter为路由钩子，里面必须有next方法，否则会阻断路由跳转，在这个钩子里面写的方法或者赋值会在路由跳转到这个页面之前执行
export default {
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  methods:{
    test(){
      console.log(this.$store.state.modules1.user_name);
      console.log(this.$store.state.name);
      // this.$store.commit("changeUserName");
      this.$store.dispatch('getMutationsFn');
      console.log(this.$store.getters.test)
      console.log(this.$store.state.modules1.user_name);
      console.log(this.$store.state.name);
      console.log(this.modules1Name);
    }
  },
  computed:{
    ...mapState({
        modules1Name: state => state.modules1.user_name
    }) 
  },
  beforeRouteEnter (to, from, next) {
    next(vm => {
      // 通过 `vm` 访问组件实例
      vm.test()
    })
  }
}
</script>

<!-- .vue文件中，style为样式部分，添加了scoped参数，表示这个样式表只对当前的.vue文件有效，而不会影响到其他模块-->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
