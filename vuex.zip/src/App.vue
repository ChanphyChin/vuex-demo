<template>
  <div id="app">
    <headerPublic></headerPublic> 
    <img src="./assets/logo.png">   
    <router-view></router-view>
    <footerPublic></footerPublic>
  </div>
</template>

<script>
//引入了头部公共模块
import headerPublic from './components/common/header.vue'
//引入了底部公共模块
import footerPublic from './components/common/footer.vue'
/*
 * components为定义引入模块的地方
*/
export default {
  name: 'app',
  components:{headerPublic,footerPublic}
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
