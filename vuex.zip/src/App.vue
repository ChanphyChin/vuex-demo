<template>
  <div id="app">
    <headerPublic></headerPublic> 
    <img src="./assets/logo.png">   
    <router-view></router-view>
    <footerPublic></footerPublic>
  </div>
</template>

<script>
import headerPublic from './components/common/header.vue'
import footerPublic from './components/common/footer.vue'
export default {
  name: 'app',
  components:{headerPublic,footerPublic}
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
