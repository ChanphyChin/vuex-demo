//这个文件为定义路由的方法
//引入vue
import Vue from 'vue'
//引入路由
import Router from 'vue-router'
// import Hello from '@/components/Hello'
//引入hello模块
const Hello = resolve => require(['@/components/Hello'], resolve);
//使用路由
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      component: Hello
    }
  ]
})
